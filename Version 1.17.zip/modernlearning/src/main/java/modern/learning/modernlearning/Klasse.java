package modern.learning.modernlearning;

public class Klasse {
}
